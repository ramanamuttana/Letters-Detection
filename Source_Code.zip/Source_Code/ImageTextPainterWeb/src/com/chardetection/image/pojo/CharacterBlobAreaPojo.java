package com.chardetection.image.pojo;

import java.awt.image.BufferedImage;

/**
 * To store Character Blob Block x, y indexes to identify character block on the
 * image
 * 
 * @author Ramana
 * 
 */
public class CharacterBlobAreaPojo {

	public int xMin;
	public int xMax;
	public int yMin;
	public int yMax;
	public int mass;
	public double diff;
	public BufferedImage image;

	public CharacterBlobAreaPojo(int xMin, int xMax, int yMin, int yMax,
			int mass) {
		this.xMin = xMin;
		this.xMax = xMax;
		this.yMin = yMin;
		this.yMax = yMax;
		this.mass = mass;
	}

	@Override
	public String toString() {
		return String.format(
				"X: %4d -> %4d, Y: %4d -> %4d, mass: %6d width:%4d height:%4d",
				xMin, xMax, yMin, yMax, mass, (xMax - xMin), (yMax - yMin));
	}

	public int getxMin() {
		return xMin;
	}

	public void setxMin(int xMin) {
		this.xMin = xMin;
	}

	public int getxMax() {
		return xMax;
	}

	public void setxMax(int xMax) {
		this.xMax = xMax;
	}

	public int getyMin() {
		return yMin;
	}

	public void setyMin(int yMin) {
		this.yMin = yMin;
	}

	public int getyMax() {
		return yMax;
	}

	public void setyMax(int yMax) {
		this.yMax = yMax;
	}

	public int getMass() {
		return mass;
	}

	public void setMass(int mass) {
		this.mass = mass;
	}

	public double getDiff() {
		return diff;
	}

	public void setDiff(double diff) {
		this.diff = diff;
	}

	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}

}
