package com.chardetection.image.pojo;

/**
 * To store character image pixel locations to paint them
 * 
 * @author Ramana
 * 
 */
public class CharacterPixelPositionPojo {

	private int x;
	private int y;
	private double diff;
	private CharacterBlobAreaPojo blob;

	public CharacterPixelPositionPojo() {

	}

	public CharacterPixelPositionPojo(int x, int y, double diff,
			CharacterBlobAreaPojo blob) {
		super();
		this.x = x;
		this.y = y;
		this.diff = diff;
		this.blob = blob;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public double getDiff() {
		return diff;
	}

	public void setDiff(double diff) {
		this.diff = diff;
	}

	public CharacterBlobAreaPojo getBlob() {
		return blob;
	}

	public void setBlob(CharacterBlobAreaPojo blob) {
		this.blob = blob;
	}

}
