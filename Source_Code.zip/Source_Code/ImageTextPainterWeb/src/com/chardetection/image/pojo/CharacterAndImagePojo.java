package com.chardetection.image.pojo;

import java.awt.image.BufferedImage;

/**
 * To store character and its corresponding image
 * 
 * @author Ramana
 * 
 */
public class CharacterAndImagePojo {

	private String character;
	private BufferedImage image;

	public CharacterAndImagePojo() {
	}

	public CharacterAndImagePojo(String character, BufferedImage image) {
		super();
		this.character = character;
		this.image = image;
	}

	public String getCharacter() {
		return character;
	}

	public void setCharacter(String character) {
		this.character = character;
	}

	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}

}
