package com.chardetection.image.helper;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.chardetection.image.pojo.CharacterAndImagePojo;
import com.chardetection.image.pojo.CharacterBlobAreaPojo;
import com.chardetection.image.pojo.CharacterPixelPositionPojo;

/**
 * To detect Characters on the image and paint them with the required color<br/>
 * It is having different methods to handle each individual functionality<br/>
 * 
 * @author Ramana
 * 
 */
public class CharacterDetectionHelper {

	/**
	 * This the process method which can calls intern all required helper
	 * methods to detect the Characters on the image and paint them with the
	 * required color
	 * 
	 * @param mainImage
	 * @param searchChars
	 * @param fontSize
	 * @param fontFamily
	 * @param paintColor
	 * @return
	 * @throws Exception
	 */
	public static BufferedImage processImage(BufferedImage mainImage,
			List<String> searchChars, String fontSize, String fontFamily,
			String paintColor) throws Exception {
		// For non given input assign default values
		fontSize = (fontSize != null) ? fontSize : "48";
		fontFamily = (fontFamily != null) ? fontFamily : "Arial";
		paintColor = (paintColor != null) ? paintColor : "Red";
		// main image to be searched on text
		BufferedImage mainImageClone = deepCopy(mainImage);
		List<CharacterAndImagePojo> toBeSearchImgs = getToBeSearchedImages(
				searchChars, fontSize, fontFamily);

		// Remove Background of the Image
		BufferedImage backgroundRemovedImage = removeBackground(mainImage);
//		ImageIO.write(backgroundRemovedImage, "jpg", new File(
//				"C:\\Users\\admin\\Desktop\\bnc.jpg"));
		int width = backgroundRemovedImage.getWidth();
		int height = backgroundRemovedImage.getHeight();

		// Get raw image data
		Raster raster = backgroundRemovedImage.getData();
		DataBuffer buffer = raster.getDataBuffer();
		DataBufferByte byteBuffer = (DataBufferByte) buffer;
		byte[] srcData = byteBuffer.getData(0);

		if (!isValidByteType(buffer)) {
			return null;
		}

		if (!isValidNumBanks(buffer)) {
			return null;
		}

		if (!isValidImgDataSize(width, height, srcData)) {
			return null;
		}

		// Output Image info
		System.out.printf(
				"image info:  width: %d, height: %d, num bytes: %d\n", width,
				height, srcData.length);

		// Create Monochrome version - using basic threshold technique
		byte[] monoData = new byte[width * height];
		int srcPtr = 0;
		int monoPtr = 0;

		while (srcPtr < srcData.length) {
			int val = ((srcData[srcPtr] & 0xFF) + (srcData[srcPtr + 1] & 0xFF) + (srcData[srcPtr + 2] & 0xFF)) / 3;
			monoData[monoPtr] = (val > 128) ? (byte) 0xFF : 0;

			srcPtr += 3;
			monoPtr += 1;
		}

		byte[] dstData = new byte[srcData.length];

		// Create Blob Finder
		ArrayList<CharacterBlobAreaPojo> blobList = new ArrayList<CharacterBlobAreaPojo>();
		detectCharBlobsInMainImage(width, height, monoData, dstData, 0, -1,
				(byte) 0, blobList);

		// List Blobs
		System.out.printf("Found %d blobs:\n", blobList.size());
		for (CharacterBlobAreaPojo blob : blobList)
			System.out.println(blob);

		// Associate Sub Images with the blob data
		fillCharBlockSubImagesFromMainImage(blobList, backgroundRemovedImage);

		for (CharacterAndImagePojo toBeSearchImg : toBeSearchImgs) {
			CharacterBlobAreaPojo aBlobBlock = searchSubImageBlobOnMainImage(
					blobList, toBeSearchImg);
			if (aBlobBlock != null) {
				List<CharacterPixelPositionPojo> charPixelsToBePaintList = getCharPixelsToBePaint(
						backgroundRemovedImage, aBlobBlock.getxMin() - 5,
						aBlobBlock.getyMin() - 5,
						(aBlobBlock.getxMax() - aBlobBlock.getxMin()) + 10,
						(aBlobBlock.getyMax() - aBlobBlock.getyMin() + 10));
				paintCharPixelsOnMainImage(mainImageClone,
						charPixelsToBePaintList, paintColor);
			}

		}

		return mainImageClone;
	}

	/**
	 * To clone the given image
	 * 
	 * @param bi
	 * @return
	 */
	public static BufferedImage deepCopy(BufferedImage bi) {
		ColorModel cm = bi.getColorModel();
		boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
		WritableRaster raster = bi.copyData(null);
		return new BufferedImage(cm, raster, isAlphaPremultiplied, null);
	}

	/**
	 * Generate the images for the given list of characters
	 * 
	 * @param searchChars
	 * @param fontSize
	 * @param fontFamily
	 * @return
	 * @throws IOException 
	 */
	public static List<CharacterAndImagePojo> getToBeSearchedImages(
			List<String> searchChars, String fontSize, String fontFamily) throws IOException {
		List<CharacterAndImagePojo> toBeSearchImgs = new ArrayList<CharacterAndImagePojo>();
//		for (String searchChar : searchChars) {
//			toBeSearchImgs.add(new CharacterAndImagePojo(searchChar,
//					getImageFromText(searchChar, fontSize, fontFamily)));
//		}
		toBeSearchImgs.add(new CharacterAndImagePojo("S", ImageIO.read(CharacterDetectionHelper.class.getClassLoader().getResourceAsStream("com/chardetection/image/letters/S.jpg"))));
		toBeSearchImgs.add(new CharacterAndImagePojo("T", ImageIO.read(CharacterDetectionHelper.class.getClassLoader().getResourceAsStream("com/chardetection/image/letters/T.jpg"))));
		toBeSearchImgs.add(new CharacterAndImagePojo("U", ImageIO.read(CharacterDetectionHelper.class.getClassLoader().getResourceAsStream("com/chardetection/image/letters/U.jpg"))));
		return toBeSearchImgs;
	}

	/**
	 * For dynamically generated black and white image trim the white space
	 * around the character
	 * 
	 * @param image
	 * @return
	 */
	public static BufferedImage trimWhiteSpace(BufferedImage image) {
		int x1 = Integer.MAX_VALUE, y1 = Integer.MAX_VALUE, x2 = 0, y2 = 0;
		for (int x = 0; x < image.getWidth(); x++) {
			for (int y = 0; y < image.getHeight(); y++) {
				int argb = image.getRGB(x, y);
				if (argb != -1) {
					x1 = Math.min(x1, x);
					y1 = Math.min(y1, y);
					x2 = Math.max(x2, x);
					y2 = Math.max(y2, y);
				}
			}
		}
		WritableRaster r = image.getRaster();
		ColorModel cm = image.getColorModel();
		r = r.createWritableChild(x1, y1, x2 - x1, y2 - y1, 0, 0, null);
		return new BufferedImage(cm, r, cm.isAlphaPremultiplied(), null);
	}

	/**
	 * To generate the Black and white image for the given character dynamically
	 * with the java
	 * 
	 * @param text
	 * @param fontSize
	 * @param fontFamily
	 * @return
	 */
	public static BufferedImage getImageFromText(String text, String fontSize,
			String fontFamily) {
		BufferedImage bufferedImage = new BufferedImage(50, 50,
				BufferedImage.TYPE_INT_RGB);
		Graphics graphics = bufferedImage.getGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, 50, 50);
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font(fontFamily, Font.PLAIN, Integer
				.parseInt(fontSize)));
		graphics.drawString(text, 5, 45);
		return trimWhiteSpace(bufferedImage);
	}

	/**
	 * Paint the given pixels with given color
	 * 
	 * @param image
	 * @param matches
	 * @param paintColor
	 */
	public static void paintCharPixelsOnMainImage(BufferedImage image,
			List<CharacterPixelPositionPojo> matches, String paintColor) {
		for (CharacterPixelPositionPojo match : matches) {
			if ("Red".equals(paintColor)) {
				image.setRGB(match.getX(), match.getY(),
						new Color(255, 0, 0).getRGB());
			} else if ("Green".equals(paintColor)) {
				image.setRGB(match.getX(), match.getY(),
						new Color(0, 255, 0).getRGB());
			} else if ("Blue".equals(paintColor)) {
				image.setRGB(match.getX(), match.getY(),
						new Color(0, 0, 255).getRGB());
			} else {
				image.setRGB(match.getX(), match.getY(),
						new Color(255, 0, 0).getRGB());
			}
		}
	}

	/**
	 * To compare required character image with character blocks on the main
	 * image
	 * 
	 * @param blobList
	 * @param charImagePojo
	 * @return
	 */
	public static CharacterBlobAreaPojo searchSubImageBlobOnMainImage(
			ArrayList<CharacterBlobAreaPojo> blobList,
			CharacterAndImagePojo charImagePojo) {
		List<CharacterPixelPositionPojo> matchs = new ArrayList<>();
		System.out.println("Searching Image with character : "
				+ charImagePojo.getCharacter());
		for (CharacterBlobAreaPojo blob : blobList) {
			BufferedImage image = blob.getImage();
			if (image != null) {
				int w1 = image.getWidth();
				int h1 = image.getHeight();
				BufferedImage charImage = charImagePojo.getImage();
				int w2 = charImage.getWidth();
				int h2 = charImage.getHeight();
				System.out
						.printf("Big Image width :%4d height:%4d  Small Image width :%4d height:%4d \n ",
								w1, h1, w2, h2);
				if (w2 <= w1 && h2 <= h1) {

					for (int x = 0; x < w1 - w2; x++) {
						for (int y = 0; y < h1 - h2; y++) {
							double comp = compareImages(
									image.getSubimage(x, y, w2, h2), charImage);
							matchs.add(new CharacterPixelPositionPojo(x, y,
									comp, blob));
						}
					}
				}
			}
		}

		System.out.println("No.of Matches : " + matchs.size());
		CharacterBlobAreaPojo bestBlob = null;
		double lowestDiff = Double.POSITIVE_INFINITY;
		Set<Double> differences = new TreeSet<>();
		if (matchs.size() > 0) {
			for (CharacterPixelPositionPojo match : matchs) {
				double comp = match.getDiff();
				differences.add(comp);
				if (comp < lowestDiff) {
					lowestDiff = comp;
					bestBlob = match.getBlob();
				}
			}
		}
		System.out.println("Differences : " + differences);
		return bestBlob;
	}

	/**
	 * Get character blocks as sub images to compare them with the required
	 * character images
	 * 
	 * @param blobBlocks
	 * @param backgroundRemovedImage
	 */
	public static void fillCharBlockSubImagesFromMainImage(
			List<CharacterBlobAreaPojo> blobBlocks,
			BufferedImage backgroundRemovedImage) {
		int x =1;
		for (CharacterBlobAreaPojo blob : blobBlocks) {
			try {
				if ((blob.getxMax() - blob.getxMin()) >= 24
						&& (blob.getyMax() - blob.getyMin()) >= 24) {
					blob.setImage(backgroundRemovedImage.getSubimage(
							blob.getxMin()-5, blob.getyMin()-5,
							(blob.getxMax() - blob.getxMin())+10,
							(blob.getyMax() - blob.getyMin())+10));
//					ImageIO.write(blob.getImage(), "jpg", new File(
//							"C:\\Users\\admin\\Desktop\\processImage"+(x++)+".jpg"));
					
				}
			} catch (Exception e) {
				System.out
						.println("Error in finding character blocks in main image");
				e.printStackTrace();
			}

		}
	}

	/**
	 * Determines how different two identically sized regions are.
	 */
	public static double compareImages(BufferedImage im1, BufferedImage im2) {
		assert (im1.getHeight() == im2.getHeight() && im1.getWidth() == im2
				.getWidth());
		double variation = 0.0;
		for (int x = 0; x < im1.getWidth(); x++) {
			for (int y = 0; y < im1.getHeight(); y++) {
				variation += compareARGB(im1.getRGB(x, y), im2.getRGB(x, y))
						/ Math.sqrt(3);
			}
		}
		return variation / (im1.getWidth() * im1.getHeight());
	}

	/**
	 * Calculates the difference between two ARGB colours
	 * (BufferedImage.TYPE_INT_ARGB).
	 */
	public static double compareARGB(int rgb1, int rgb2) {
		double r1 = ((rgb1 >> 16) & 0xFF) / 255.0;
		double r2 = ((rgb2 >> 16) & 0xFF) / 255.0;
		double g1 = ((rgb1 >> 8) & 0xFF) / 255.0;
		double g2 = ((rgb2 >> 8) & 0xFF) / 255.0;
		double b1 = (rgb1 & 0xFF) / 255.0;
		double b2 = (rgb2 & 0xFF) / 255.0;
		double a1 = ((rgb1 >> 24) & 0xFF) / 255.0;
		double a2 = ((rgb2 >> 24) & 0xFF) / 255.0;
		// if there is transparency, the alpha values will make difference
		// smaller
		return a1
				* a2
				* Math.sqrt((r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2)
						+ (b1 - b2) * (b1 - b2));
	}

	/**
	 * To get character pixel positions on the given image
	 * 
	 * @param bigImage
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 * @return
	 */
	public static List<CharacterPixelPositionPojo> getCharPixelsToBePaint(
			BufferedImage bigImage, int x, int y, int width, int height) {
		List<CharacterPixelPositionPojo> matchs = new ArrayList<>();

		for (int i = x; i < (x + width); i++)
			for (int j = y; j < (y + height); j++) {
				// System.out.println(bigImage.getRGB(i, j));
				if (bigImage.getRGB(i, j) != -1) {
					// bigImage.setRGB(i, j, 255);
					matchs.add(new CharacterPixelPositionPojo(i, j, 0.0, null));
				}

			}

		return matchs;
	}

	/**
	 * To remove the background of the image and convert background to white
	 * character to black color
	 * 
	 * @param src
	 * @return
	 */
	public static BufferedImage removeBackground(BufferedImage src) {
		System.out.println(src.getWidth() + " X " + src.getHeight());
		Color white = new Color(255, 255, 255);
		Color black = new Color(0, 0, 0);
		BufferedImage imageOut = src;

		for (int i = 0; i < src.getWidth(); i++) {
			for (int j = 0; j < src.getHeight(); j++) {
				Color c = new Color(src.getRGB(i, j));

				if ((c.getRed() > 200 && c.getBlue() < 60 && c.getGreen() < 60)
						||

						(c.getRed() > 200 && c.getBlue() < 60 && c.getGreen() > 200)
						||

						(c.getRed() > 200 && c.getBlue() > 200 && c.getGreen() < 60)
						||

						(c.getRed() < 60 && c.getBlue() > 200 && c.getGreen() < 60)
						||

						(c.getRed() < 60 && c.getBlue() < 60 && c.getGreen() > 200)
						||

						(c.getRed() < 60 && c.getBlue() > 200 && c.getGreen() > 200)
						||

						(c.getRed() == 0 && c.getBlue() == 0 && c.getGreen() == 0)
						||

						(c.getRed() == 255 && c.getBlue() == 255 && c.getGreen() == 255)) {

					imageOut.setRGB(i, j, black.getRGB());
				} else {
					imageOut.setRGB(i, j, white.getRGB());
				}
			}
		}
		return imageOut;
	}

	/**
	 * To detect character bolb blocks on the given image
	 * 
	 * @param width
	 * @param height
	 * @param srcData
	 * @param dstData
	 * @param minBlobMass
	 * @param maxBlobMass
	 * @param matchVal
	 * @param blobList
	 * @return
	 */
	public static List<CharacterBlobAreaPojo> detectCharBlobsInMainImage(
			int width, int height, byte[] srcData, byte[] dstData,
			int minBlobMass, int maxBlobMass, byte matchVal,
			List<CharacterBlobAreaPojo> blobList) {

		int[] labelBuffer = new int[width * height];
		// The maximum number of blobs is given by an image filled with equally
		// spaced single pixel
		// blobs. For images with less blobs, memory will be wasted, but this
		// approach is simpler and
		// probably quicker than dynamically resizing arrays
		int tableSize = width * height / 4;
		int[] labelTable = new int[tableSize];
		int[] xMinTable = new int[tableSize];
		int[] xMaxTable = new int[tableSize];
		int[] yMinTable = new int[tableSize];
		int[] yMaxTable = new int[tableSize];
		int[] massTable = new int[tableSize];

		if (dstData != null && dstData.length != srcData.length * 3)
			throw new IllegalArgumentException(
					"Bad array lengths: srcData 1 byte/pixel (mono), dstData 3 bytes/pixel (RGB)");

		// This is the neighbouring pixel pattern. For position X, A, B, C & D
		// are checked
		// A B C
		// D X

		int srcPtr = 0;
		int aPtr = -width - 1;
		int bPtr = -width;
		int cPtr = -width + 1;
		int dPtr = -1;

		int label = 1;

		// Iterate through pixels looking for connected regions. Assigning
		// labels
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				labelBuffer[srcPtr] = 0;

				// Check if on foreground pixel
				if (srcData[srcPtr] == matchVal) {
					// Find label for neighbours (0 if out of range)
					int aLabel = (x > 0 && y > 0) ? labelTable[labelBuffer[aPtr]]
							: 0;
					int bLabel = (y > 0) ? labelTable[labelBuffer[bPtr]] : 0;
					int cLabel = (x < width - 1 && y > 0) ? labelTable[labelBuffer[cPtr]]
							: 0;
					int dLabel = (x > 0) ? labelTable[labelBuffer[dPtr]] : 0;

					// Look for label with least value
					int min = Integer.MAX_VALUE;
					if (aLabel != 0 && aLabel < min)
						min = aLabel;
					if (bLabel != 0 && bLabel < min)
						min = bLabel;
					if (cLabel != 0 && cLabel < min)
						min = cLabel;
					if (dLabel != 0 && dLabel < min)
						min = dLabel;

					// If no neighbours in foreground
					if (min == Integer.MAX_VALUE) {
						labelBuffer[srcPtr] = label;
						labelTable[label] = label;

						// Initialise min/max x,y for label
						yMinTable[label] = y;
						yMaxTable[label] = y;
						xMinTable[label] = x;
						xMaxTable[label] = x;
						massTable[label] = 1;

						label++;
					}

					// Neighbour found
					else {
						// Label pixel with lowest label from neighbours
						labelBuffer[srcPtr] = min;

						// Update min/max x,y for label
						yMaxTable[min] = y;
						massTable[min]++;
						if (x < xMinTable[min])
							xMinTable[min] = x;
						if (x > xMaxTable[min])
							xMaxTable[min] = x;

						if (aLabel != 0)
							labelTable[aLabel] = min;
						if (bLabel != 0)
							labelTable[bLabel] = min;
						if (cLabel != 0)
							labelTable[cLabel] = min;
						if (dLabel != 0)
							labelTable[dLabel] = min;
					}
				}

				srcPtr++;
				aPtr++;
				bPtr++;
				cPtr++;
				dPtr++;
			}
		}

		// Iterate through labels pushing min/max x,y values towards minimum
		// label
		if (blobList == null)
			blobList = new ArrayList<CharacterBlobAreaPojo>();

		for (int i = label - 1; i > 0; i--) {
			if (labelTable[i] != i) {
				if (xMaxTable[i] > xMaxTable[labelTable[i]])
					xMaxTable[labelTable[i]] = xMaxTable[i];
				if (xMinTable[i] < xMinTable[labelTable[i]])
					xMinTable[labelTable[i]] = xMinTable[i];
				if (yMaxTable[i] > yMaxTable[labelTable[i]])
					yMaxTable[labelTable[i]] = yMaxTable[i];
				if (yMinTable[i] < yMinTable[labelTable[i]])
					yMinTable[labelTable[i]] = yMinTable[i];
				massTable[labelTable[i]] += massTable[i];

				int l = i;
				while (l != labelTable[l])
					l = labelTable[l];
				labelTable[i] = l;
			} else {
				// Ignore blobs that butt against corners
				if (i == labelBuffer[0])
					continue; // Top Left
				if (i == labelBuffer[width])
					continue; // Top Right
				if (i == labelBuffer[(width * height) - width + 1])
					continue; // Bottom Left
				if (i == labelBuffer[(width * height) - 1])
					continue; // Bottom Right

				if (massTable[i] >= minBlobMass
						&& (massTable[i] <= maxBlobMass || maxBlobMass == -1)) {
					CharacterBlobAreaPojo blob = new CharacterBlobAreaPojo(
							xMinTable[i], xMaxTable[i], yMinTable[i],
							yMaxTable[i], massTable[i]);
					blobList.add(blob);
				}
			}
		}

		return blobList;
	}

	/**
	 * To check image data type
	 * 
	 * @param buffer
	 * @return
	 */
	public static boolean isValidByteType(DataBuffer buffer) {
		int type = buffer.getDataType();
		if (type != DataBuffer.TYPE_BYTE) {
			System.err.println("Wrong image data type");
			return false;
		}
		return true;
	}

	/**
	 * To check image data format
	 * 
	 * @param buffer
	 * @return
	 */
	public static boolean isValidNumBanks(DataBuffer buffer) {
		if (buffer.getNumBanks() != 1) {
			System.err.println("Wrong image data format");
			return false;
		}
		return true;
	}

	/**
	 * Sanity check image : to check weather the image data size is valid or not
	 * 
	 * @param width
	 * @param height
	 * @param srcData
	 * @return
	 */
	public static boolean isValidImgDataSize(int width, int height,
			byte[] srcData) {
		if (width * height * 3 != srcData.length) {
			System.err
					.println("Unexpected image data size. Should be RGB image");
			return false;
		}
		return true;
	}

	/**
	 * Reads small and large images from servlet object and return map which
	 * contains extracted images
	 * 
	 * @param request
	 * @param response
	 * @return
	 */

	public static BufferedImage readImage(HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("Reading images from request...");
		BufferedImage mainImage = null;
		try {
			Collection<Part> parts = request.getParts();
			Iterator<Part> iterator = parts.iterator();
			while (iterator.hasNext()) {
				Part item = iterator.next();
				String fieldName = item.getName();
				System.out.println("Reading File field Name : " + fieldName);
				if ("mainImage".equals(fieldName)) {
					InputStream in = item.getInputStream();
					mainImage = ImageIO.read(in);
					break;
				}
			}

		} catch (Exception e) {
			System.out.println("Error while reading uploaded images" + e);
		}
		return mainImage;
	}

	/**
	 * It converts BufferedImage to byte array
	 * 
	 * @param processedImage
	 * @return
	 * @throws IOException
	 */
	public static byte[] getProcessedImageBytes(BufferedImage processedImage)
			throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(processedImage, "jpg", baos);
		baos.flush();
		return baos.toByteArray();
	}

	/**
	 * From comma separated string prepare the list of strings
	 * 
	 * @param searchText
	 * @return
	 */
	public static List<String> getSearchCharacters(String searchText) {
		List<String> searchChars = new ArrayList<>();
		if (searchText != null) {
			StringTokenizer st = new StringTokenizer(searchText, ",");
			while (st.hasMoreTokens()) {
				searchChars.add(st.nextToken());
			}
			System.out.println("Given Search Characters are : " + searchChars);

		}
		return searchChars;
	}

	/**
	 * To test the helper as a stand alone program
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		BufferedImage mainImage = ImageIO.read(new File(
				"C:\\Users\\admin\\Desktop\\demo.jpg"));
		BufferedImage processImage = processImage(mainImage,
				Arrays.asList("S", "T", "U"), "48", "Arial", "Blue");
		ImageIO.write(processImage, "jpg", new File(
				"C:\\Users\\admin\\Desktop\\processImage.jpg"));
		
	}

}
