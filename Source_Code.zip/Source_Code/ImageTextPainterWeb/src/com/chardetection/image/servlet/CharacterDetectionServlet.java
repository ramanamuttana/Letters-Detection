package com.chardetection.image.servlet;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chardetection.image.helper.CharacterDetectionHelper;

/**
 * Get submitted form info using servlet3 API<br/>
 * Validate, and detect the characters using {@link CharacterDetectionHelper}<br/>
 * Once processing is done it will store the resulted image on session sope <br/>
 * Finally Forward the control to charDetection.jsp <br/>
 * In case any failure in the processing it will forward the request to
 * error.jsp <br/>
 * 
 * @author Ramana
 * 
 */
@WebServlet("/detect")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, maxFileSize = 1024 * 1024 * 10, maxRequestSize = 1024 * 1024 * 50)
public class CharacterDetectionServlet extends HttpServlet {
	private static final long serialVersionUID = -3208409086358916855L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Image processing request received...");

		BufferedImage mainImage = CharacterDetectionHelper.readImage(request,
				response);
		List<String> searchChars = CharacterDetectionHelper
				.getSearchCharacters("S,T,U");
		String fontSize = request.getParameter("fontSize");
		String fontFamily = request.getParameter("fontFamily");
		String paintColor = request.getParameter("paintColor");
		if (mainImage != null && searchChars.size() > 0) {
			try {
				BufferedImage mainImageClone = CharacterDetectionHelper
						.deepCopy(mainImage);
				BufferedImage processedImage = CharacterDetectionHelper
						.processImage(mainImage, searchChars, fontSize,
								fontFamily, paintColor);
				if (processedImage == null) {
					System.out.println("Error in processing image");
					RequestDispatcher rd = request
							.getRequestDispatcher("/WEB-INF/error.jsp");
					rd.forward(request, response);
				}
				HttpSession session = request.getSession();
				session.setAttribute("mainImage", mainImageClone);
				session.setAttribute("processedImage", processedImage);
				session.setAttribute("searchText", searchChars);
				RequestDispatcher rd = request
						.getRequestDispatcher("/WEB-INF/charDetection.jsp");
				rd.forward(request, response);
				System.out.println("Image processing done");

			} catch (Exception e) {
				System.out.println("Error while reading uploaded images" + e);
			}
		} else {
			RequestDispatcher rd = request
					.getRequestDispatcher("/WEB-INF/error.jsp");
			rd.forward(request, response);
		}

	}
}
