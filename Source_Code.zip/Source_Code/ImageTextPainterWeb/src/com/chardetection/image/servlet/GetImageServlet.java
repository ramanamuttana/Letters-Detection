package com.chardetection.image.servlet;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chardetection.image.helper.CharacterDetectionHelper;

/**
 * download requested image which is on session object
 * 
 * @author Ramana
 * 
 */
@WebServlet("/download")
public class GetImageServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Download image request received");
		try {
			String image = request.getParameter("image");
			System.out.println("image : " + image);
			HttpSession session = request.getSession();
			BufferedImage bufferedImage = (BufferedImage) session
					.getAttribute(image);

			byte[] imageBytes = CharacterDetectionHelper
					.getProcessedImageBytes(bufferedImage);

			ServletContext context = getServletContext();

			// sets MIME type for the file download
			String mimeType = context.getMimeType(image);
			if (mimeType == null) {
				mimeType = "application/octet-stream";
			}

			// set content properties and header attributes for the response
			response.setContentType(mimeType);
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"",
					image + ".jpeg");
			response.setHeader(headerKey, headerValue);
			response.getOutputStream().write(imageBytes);

		} catch (Exception e) {
			System.out.println("Error while downloading image");
			e.printStackTrace();
		}

	}

}
