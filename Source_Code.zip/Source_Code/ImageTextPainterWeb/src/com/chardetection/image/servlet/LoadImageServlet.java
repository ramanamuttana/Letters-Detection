package com.chardetection.image.servlet;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chardetection.image.helper.CharacterDetectionHelper;

/**
 * To display image on the charDetection.jsp page from session object<br/>
 * 
 * @author Ramana
 * 
 */
@WebServlet("/load")
public class LoadImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Download image request received");
		try {
			String image = request.getParameter("image");
			System.out.println("image : " + image);
			HttpSession session = request.getSession();
			BufferedImage bufferedImage = (BufferedImage) session
					.getAttribute(image);

			byte[] imageBytes = CharacterDetectionHelper
					.getProcessedImageBytes(bufferedImage);

			response.setContentType("image/jpg");
			response.setContentLength(imageBytes.length);

			response.getOutputStream().write(imageBytes);

		} catch (Exception e) {
			System.out.println("Error while loading image");
			e.printStackTrace();
		}

	}

}
